//
//  ViewController.swift
//  calc(Romanova)
//
//  Created by Admin on 30.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var buttonSlash: UIButton!
    @IBOutlet weak var buttonAC: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        buttonAC.layer.cornerRadius = 36
        
    }


}

